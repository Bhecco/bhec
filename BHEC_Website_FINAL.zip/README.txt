BHEC – Biblical Home Education Community
PAQUETE LISTO PARA GITHUB PAGES

Archivos:
- index.html
- logo-bhec.jpg

Datos incluidos:
Correo: bheccommunity@gmail.com
WhatsApp: +57 318 460 0550
Instagram: @bheccommunity
Telegram: @bhecco

Para publicar: sube index.html y logo-bhec.jpg directamente a la raíz de un repositorio público en GitHub y activa GitHub Pages desde Settings > Pages > Deploy from a branch > main / (root).
